<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'mysite' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '%k)%GT3<uz[G^UgHnOaLE5?m!<Qz23&D8SA3H1Tsvz`Pb_X;1yMt#}q{c@;E13`V' );
define( 'SECURE_AUTH_KEY',  '!1jc 0LDWBuJ9U#[g$/<c8B?yuWylK%bSmI%]n&OeF7b,,@ CXx;,kLop$^I&(2b' );
define( 'LOGGED_IN_KEY',    '#l5vR pHssoVmv*T;&;6OO2{DqzJ>@ So9z_,`Ab7g]7ba:(L1I/E+&Ie^X,n}^$' );
define( 'NONCE_KEY',        'F;~e`MGib`TX8U5c@kD9R.MN.7ZF /R#u 9#9p~b<Jy`|NNblnUzChf+P&a7<V>M' );
define( 'AUTH_SALT',        ' UE5ZqxedgGbA@Fn9s7;px+^P}O3X:,@{*;c,]dB2ZmPEHM9J(KTsa6*=Q6j1ATY' );
define( 'SECURE_AUTH_SALT', 'wlQd_T%!=zQ ~mew/1ATAWAGgD>K`;@v4B<m]!Wn6k7:AKFFNl-LGGK|45NDp4G6' );
define( 'LOGGED_IN_SALT',   'IrCqP0<f+7w.+GGBae<>@$qH@B(0C$hziX>U#>jetoU;O%f]n+rHXJX,=PBj_zUf' );
define( 'NONCE_SALT',       '`p[g=Ykmi/=3^}K!_:e7U@qMPv@1N@|p0ItK,fB.pwD18/%,})3+V2+F[m}ftc57' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
